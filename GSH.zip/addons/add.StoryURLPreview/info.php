<?php
$name = "Story URL Preview";
$supported_version = "2.0.0";
$author = "Rehan Adil";
$author_url = "http://themephysics.com";