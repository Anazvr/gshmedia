<?php
userOnly();

include('requests/message/' . $a . '.php');