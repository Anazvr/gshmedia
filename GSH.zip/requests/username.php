<?php
include('requests/username/' . $a . '.php');
