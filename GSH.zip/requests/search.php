<?php
include('requests/search/' . $a . '.php');