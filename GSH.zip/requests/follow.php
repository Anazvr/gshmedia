<?php
userOnly();

include('requests/follow/' . $a . '.php');