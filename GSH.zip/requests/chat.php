<?php
if ($config['chat'] == 1)
{
	include('requests/chat/' . $a . '.php');
}