<?php

$name = 'Marvel';

$version = '1.1.0';

$author = 'Rehan Adil (MarvelKit)';

$author_website = 'http://codecanyon.net/user/MarvelKit';