<?php

$name = 'Lemon';

$version = '2.0.0';

$author = 'Rehan Adil (ThemePhysics)';

$author_website = 'http://codecanyon.net/user/ThemePhysics';