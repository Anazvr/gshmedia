<?php

$name = 'DarkNet';

$version = '1.11.02';

$author = 'Achmad Choirun Nasrukhin Wakhid [Anazvr]';

$author_website = 'http://anazvr@blogspot.co.id';