<?php
/**
Note: If you add a emoticon code where part of the code is itself an emoticon. For example: "0:)", where ":)" is an emoticon itself. Please make sure to add the former ["0:)" for example] above the latter [":)" for example]/
**/

$emo[':/'] = 'kampret.png';
$emo[':-/'] = 'kampret.png';

$emo['0:)'] = '18.png';
$emo['0:-)'] = '18.png';
$emo['O:)'] = '18.png';
$emo['O:-)'] = '18.png';

$emo[':)'] = 'biasa.png';

$emo[':D'] = '21.png';
$emo[':-D'] = '21.png';

$emo[':('] = 'nangis.png';
$emo[':-('] = 'nangis.png';
$emo['=('] = 'nangis.png';

$emo[':O-'] = 'mutah.png';

$emo[':p'] = 'melet.png';
$emo[':P'] = 'melet.png';
$emo[':-p'] = 'melet.png';
$emo[':-P'] = 'melet.png';

$emo[':o'] = 'oooo.png';
$emo[':O'] = 'oooo.png';
$emo[':0'] = 'oooo.png';

$emo['>:('] = 'anjir.png';

$emo['*:)'] = 'guy.png';
$emo[':S'] = 'guy.png';

$emo[';)'] = 'kedip.png';
$emo[';-)'] = 'kedip.png';

$emo[':PP'] = 'ngace.png';

$emo['-_-'] = 'asw.png';

$emo[':#'] = 'ciummalu.png';
$emo[':*'] = 'cium.png';

$emo['B-)'] = 'bergaya.png';
$emo['B-)'] = 'bergaya.png';

$emo['^_^'] = 'malu.png';

$emo['>.<'] = 'emon.png';

$emo['<3'] = 'keranjang.png';

?>