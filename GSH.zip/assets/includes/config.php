<?php

// MySQL Hostname / Server (for eg: 'localhost')
$sql_host = 'localhost';


// MySQL Database Name
$sql_name = 'skn';


// MySQL Database User
$sql_user = 'root';


// MySQL Database Password
$sql_pass = '';


// Site URL
$site_url = '';


// Facebook App Details
$fb_app_id = '727255330669720'; // Your Facebook App ID, Create one at http://developers.facebook.com
$fb_app_secret = '9d7023f9fb969148267ad7063a15182c'; // Your Facebook App Secret

