<?php
$config['admin_username'] = 'marvelkit';
$config['admin_password'] = 'e9aada4fd797d65069187d7a961691cc';
