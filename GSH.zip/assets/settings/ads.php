<?php
$config['ad_place_home'] = '';
$config['ad_place_messages'] = '';
$config['ad_place_timeline'] = '';
$config['ad_place_hashtag'] = '';
$config['ad_place_search'] = '';
