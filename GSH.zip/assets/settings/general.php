<?php
$config['friends'] = false;
$config['site_name'] = 'Sitename';
$config['site_title'] = 'Site Title';
$config['email'] = 'no-reply@website.com';
$config['email_verification'] = false;
$config['chat'] = true;
$config['captcha'] = true;
$config['language'] = 'english';
$config['smooth_links'] = false;
$config['censored_words'] = 'racist,retard';
$config['reg_req_birthday'] = true;
$config['reg_req_currentcity'] = true;
$config['reg_req_hometown'] = true;
$config['reg_req_about'] = true;
$config['story_character_limit'] = 0;
$config['comment_character_limit'] = 0;
$config['message_character_limit'] = 0;
